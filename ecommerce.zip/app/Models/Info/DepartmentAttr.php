<?php

namespace App\Models\Info;

class DepartmentAttr
{
    const TABLE_NAME = 'departments';
    const ID = 'id';
    const NAME = 'name';
}

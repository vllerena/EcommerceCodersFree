<?php

namespace App\Models\Info;

class ColorAttr
{
    const TABLE_NAME = 'colors';
    const ID = 'id';
    const NAME = 'name';
    const UPDATED_AT = 'updated_at';
    const CREATED_AT = 'created_at';
}

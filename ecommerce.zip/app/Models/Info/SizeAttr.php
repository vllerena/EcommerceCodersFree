<?php

namespace App\Models\Info;

class SizeAttr
{
    const TABLE_NAME = 'sizes';
    const ID = 'id';
    const NAME = 'name';
    const PRODUCT_ID = 'product_id';
    const UPDATED_AT = 'updated_at';
    const CREATED_AT = 'created_at';
}

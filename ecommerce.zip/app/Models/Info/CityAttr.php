<?php

namespace App\Models\Info;

class CityAttr
{
    const TABLE_NAME = 'cities';
    const ID = 'id';
    const NAME = 'name';
    const DEPARTMENT_ID = 'department_id';
    const COST = 'cost';
}

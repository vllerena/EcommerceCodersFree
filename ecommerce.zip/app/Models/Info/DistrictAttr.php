<?php

namespace App\Models\Info;

class DistrictAttr
{
    const TABLE_NAME = 'districts';
    const ID = 'id';
    const NAME = 'name';
    const CITY_ID = 'city_id';
}

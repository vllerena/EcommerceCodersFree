<?php

namespace App\Models\Info;

class BrandAttr
{
    const TABLE_NAME = 'brands';
    const ID = 'id';
    const NAME = 'name';
    const UPDATED_AT = 'updated_at';
    const CREATED_AT = 'created_at';
}
